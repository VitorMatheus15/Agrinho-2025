// Variáveis Globais
let dinheiro = 100; // Dinheiro inicial
let satisfacaoCidade = 80; // Satisfação inicial (0-100)
let alturaCampo = 250; // Altura da seção do campo
let plantacoes = []; // Array para armazenar as plantações
let veiculoEntrega; // Objeto para o veículo de entrega

// Cores
const COR_GRAMA = '#8BC34A';
const COR_ESTRADA = '#546E7A';
const COR_CASA_CAMPO = '#795548';
const COR_TELHADO = '#F44336';
const COR_JANELA = '#BBDEFB';
const COR_CIDADE_FUNDO = '#CFD8DC';
const COR_CASA_CIDADE = '#90A4AE';
const COR_VEICULO = '#2196F3';
const COR_RODA = '#424242';

// --- CLASSE PLANTAÇÃO ---
class Plantacao {
  constructor(x, y, largura, altura) {
    this.x = x;
    this.y = y;
    this.largura = largura;
    this.altura = altura;
    this.crescimento = 0; // 0 a 100
    this.colhivel = false;
  }

  mostrar() {
    // Fundo da plantação
    fill(COR_GRAMA);
    rect(this.x, this.y, this.largura, this.altura);

    // Representação do crescimento
    let alturaCrescida = map(this.crescimento, 0, 100, 0, this.altura);
    fill(0, 150 - this.crescimento * 1.5, 0); // Verde escuro para plantação mais madura
    rect(this.x, this.y + this.altura - alturaCrescida, this.largura, alturaCrescida);

    if (this.crescimento >= 90) { // Consideramos colhível com 90% de crescimento
      this.colhivel = true;
      fill(255, 200, 0, 150); // Brilho amarelo para indicar colhível
      rect(this.x, this.y, this.largura, this.altura);
    } else {
      this.colhivel = false;
    }
  }

  crescer() {
    if (this.crescimento < 100) {
      this.crescimento += 0.1; // Ajuste a velocidade de crescimento
    }
  }

  colher() {
    if (this.colhivel) {
      this.crescimento = 0; // Reinicia a plantação
      this.colhivel = false;
      return true; // Indica que foi colhida
    }
    return false;
  }
}

// --- CLASSE VEÍCULO DE ENTREGA (Caminhão) ---
class VeiculoEntrega {
  constructor() {
    this.x = width / 2; // Começa no meio da estrada do campo
    this.y = alturaCampo - 30; // Posição na estrada
    this.velocidade = 0;
    this.entregando = false;
    this.alimentosCarregados = 0;
  }

  mostrar() {
    // Corpo do caminhão (retângulo)
    fill(COR_VEICULO);
    rect(this.x - 25, this.y - 15, 50, 30);
    // Cabine do caminhão (retângulo menor)
    rect(this.x + 15, this.y - 10, 20, 20);

    // Rodas (círculos)
    fill(COR_RODA);
    ellipse(this.x - 15, this.y + 15, 15, 15);
    ellipse(this.x + 15, this.y + 15, 15, 15);

    // Alimentos visíveis
    if (this.alimentosCarregados > 0) {
      fill(255, 165, 0, 150); // Cor de alimento
      ellipse(this.x, this.y - 10, 10 + this.alimentosCarregados * 2);
    }
  }

  carregarAlimento(quantidade) {
    this.alimentosCarregados += quantidade;
  }

  iniciarEntrega() {
    if (this.alimentosCarregados > 0 && !this.entregando) {
      this.entregando = true;
      this.velocidade = 3; // Velocidade para entrega
    }
  }

  movimentar() {
    if (this.entregando) {
      this.y += this.velocidade; // Move para baixo em direção à cidade

      // Se chegou na cidade
      if (this.y > height - 50) { // Perto do final da tela
        this.entregando = false;
        this.velocidade = 0;
        this.y = alturaCampo - 30; // Volta para a posição inicial no campo
        return true; // Indica que a entrega foi feita
      }
    }
    return false;
  }

  descarregarAlimentos() {
    let quantidadeDescarregada = this.alimentosCarregados;
    this.alimentosCarregados = 0;
    return quantidadeDescarregada;
  }
}

function setup() {
  createCanvas(800, 600); // Largura e altura da tela

  // Inicializar plantações (exemplo com 3 plantações alinhadas)
  let numPlantacoes = 4;
  let larguraPlantacao = 150;
  let espacoPlantacao = 20;
  let xInicialPlantacao = (width - (numPlantacoes * larguraPlantacao + (numPlantacoes - 1) * espacoPlantacao)) / 2;

  for (let i = 0; i < numPlantacoes; i++) {
    plantacoes.push(new Plantacao(xInicialPlantacao + i * (larguraPlantacao + espacoPlantacao), 50, larguraPlantacao, 100));
  }

  // Inicializar veículo de entrega
  veiculoEntrega = new VeiculoEntrega();
}

function draw() {
  // --- Desenha o Campo ---
  background(COR_GRAMA); // Cor de fundo do campo
  noStroke();

  // Desenha a estrada do campo
  fill(COR_ESTRADA);
  rect(0, alturaCampo - 50, width, 100);

  // Desenha as plantações
  for (let plantacao of plantacoes) {
    plantacao.mostrar();
    plantacao.crescer();
  }

  // Desenha as casas do campo (exemplo com 2 casas alinhadas)
  let larguraCasaCampo = 80;
  let alturaCasaCampo = 70;
  let xCasaCampo1 = width / 4 - larguraCasaCampo / 2;
  let xCasaCampo2 = 3 * width / 4 - larguraCasaCampo / 2;
  let yCasaCampo = alturaCampo - 150;

  // Casa 1
  fill(COR_CASA_CAMPO); // Corpo da casa (retângulo)
  rect(xCasaCampo1, yCasaCampo, larguraCasaCampo, alturaCasaCampo);
  fill(COR_TELHADO); // Telhado (triângulo)
  triangle(xCasaCampo1, yCasaCampo, xCasaCampo1 + larguraCasaCampo / 2, yCasaCampo - alturaCasaCampo / 2, xCasaCampo1 + larguraCasaCampo, yCasaCampo);
  fill(COR_JANELA); // Janela (quadrado)
  rect(xCasaCampo1 + larguraCasaCampo / 4, yCasaCampo + alturaCasaCampo / 4, larguraCasaCampo / 2, alturaCasaCampo / 2);

  // Casa 2
  fill(COR_CASA_CAMPO); // Corpo da casa (retângulo)
  rect(xCasaCampo2, yCasaCampo, larguraCasaCampo, alturaCasaCampo);
  fill(COR_TELHADO); // Telhado (triângulo)
  triangle(xCasaCampo2, yCasaCampo, xCasaCampo2 + larguraCasaCampo / 2, yCasaCampo - alturaCasaCampo / 2, xCasaCampo2 + larguraCasaCampo, yCasaCampo);
  fill(COR_JANELA); // Janela (quadrado)
  rect(xCasaCampo2 + larguraCasaCampo / 4, yCasaCampo + alturaCasaCampo / 4, larguraCasaCampo / 2, alturaCasaCampo / 2);


  // Desenha o veículo de entrega
  veiculoEntrega.mostrar();
  if (veiculoEntrega.movimentar()) {
    // Se a entrega foi concluída, atualiza dinheiro e satisfação
    let alimentosEntregues = veiculoEntrega.descarregarAlimentos();
    dinheiro += alimentosEntregues * 10; // Ganha dinheiro por alimento
    satisfacaoCidade += alimentosEntregues * 2; // Aumenta satisfação
    satisfacaoCidade = constrain(satisfacaoCidade, 0, 100); // Garante que a satisfação fique entre 0 e 100
  }


  // --- Desenha a Cidade ---
  fill(COR_CIDADE_FUNDO);
  rect(0, alturaCampo, width, height - alturaCampo); // Fundo da cidade

  // Desenha as casas da cidade (exemplo com 5 casas alinhadas)
  let numCasasCidade = 5;
  let larguraCasaCidade = 60;
  let alturaCasaCidade = 80;
  let espacoCasaCidade = 15;
  let xInicialCasaCidade = (width - (numCasasCidade * larguraCasaCidade + (numCasasCidade - 1) * espacoCasaCidade)) / 2;
  let yCasaCidade = height - alturaCasaCidade - 20;

  for (let i = 0; i < numCasasCidade; i++) {
    // Corpo da casa (quadrado ou retângulo)
    fill(COR_CASA_CIDADE);
    rect(xInicialCasaCidade + i * (larguraCasaCidade + espacoCasaCidade), yCasaCidade, larguraCasaCidade, alturaCasaCidade);
    // Janelas (pequenos retângulos ou quadrados)
    fill(COR_JANELA);
    rect(xInicialCasaCidade + i * (larguraCasaCidade + espacoCasaCidade) + 10, yCasaCidade + 10, 15, 15);
    rect(xInicialCasaCidade + i * (larguraCasaCidade + espacoCasaCidade) + larguraCasaCidade - 25, yCasaCidade + 10, 15, 15);
  }

  // --- Exibe informações do jogo ---
  fill(0); // Cor do texto
  textSize(20);
  textAlign(LEFT);
  text(`Dinheiro: $${dinheiro}`, 20, height - 70);
  text(`Satisfação da Cidade: ${floor(satisfacaoCidade)}%`, 20, height - 100);

  // Diminui a satisfação da cidade lentamente se não houver entregas
  if (frameCount % 140 === 0) { // A cada 4 segundos (60 fps * 2)
    satisfacaoCidade -= 1;
    satisfacaoCidade = constrain(satisfacaoCidade, 0, 100);
  }

  // Verifica se o jogador perdeu (satisfação muito baixa)
  if (satisfacaoCidade <= 10) {
    fill(255, 0, 0);
    textSize(40);
    textAlign(CENTER, CENTER);
    text("A CIDADE ESTÁ IRRITADA! VOCÊ PERDEU!", width / 2, height / 2);
    noLoop(); // Para o jogo
  }
}

function mousePressed() {
  // Permite colher clicando nas plantações
  for (let plantacao of plantacoes) {
    if (mouseX > plantacao.x && mouseX < plantacao.x + plantacao.largura &&
      mouseY > plantacao.y && mouseY < plantacao.y + plantacao.altura) {
      if (plantacao.colher()) {
        veiculoEntrega.carregarAlimento(1); // Adiciona um alimento ao veículo
      }
    }
  }

  // Botão para iniciar entrega (se o caminhão não estiver em movimento)
  // Poderíamos criar um botão visual, mas por enquanto, clique em qualquer lugar na estrada para ativar a entrega
  if (mouseY > alturaCampo - 50 && mouseY < alturaCampo + 50 && !veiculoEntrega.entregando) {
     veiculoEntrega.iniciarEntrega();
  }
}